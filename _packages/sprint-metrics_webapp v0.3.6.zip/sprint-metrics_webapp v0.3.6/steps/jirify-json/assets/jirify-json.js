//needs defaultWorkitemModelDefinition.js to be sourced in html

let loadedJsonFilename = '';
let loadedJson;
let jirifiedJson;

const loadJsonButtonId = 'loadJsonButton';
const convertButtonId = 'convertButton';
const downloadButtonId = 'downloadButton';

document.getElementById(loadJsonButtonId).addEventListener('click', handleLoadJsonButtonClick);
document.getElementById('filePicker').addEventListener('change', handleFilePickerChange);
document.getElementById(convertButtonId).addEventListener('click', handleconvertButtonClick);
document.getElementById(downloadButtonId).addEventListener('click', handleDownloadJsonButtonClick);





/*----------------------------------------
  ACTION HANDLERS
  --------------------------------------*/

function handleLoadJsonButtonClick(event) {
    document.getElementById('filePicker').click();
}

function handleFilePickerChange(event) {
    //TODO: handle errors

    const file = event.target.files[0];
    if (file) {
        hideButton(loadJsonButtonId);

        loadedJsonFilename = file.name;
        showFilename(loadedJsonFilename);

        loadJSONFile(file, handleJsonLoaded);
    } else {
        showFilename('No file selected');
        showDataViewer('');
    }
}

function handleJsonLoaded(loadedJsonText) {
    console.log('handle loaded Json data');

    loadedJson = JSON.parse(loadedJsonText);
    console.log(loadedJson);

    const workItemModelDefinition = workitemModelDefinition();
    const loadedWorkitemAttributes = scanWorkitemAttributes(loadedJson);

    //TODO: enable config changes checkboxes   
    showWorkItemChangesPreview(workItemModelDefinition, loadedWorkitemAttributes);
    showButton(convertButtonId);
}

function handleconvertButtonClick(event) {
    hideButton(convertButtonId);

    jirifiedJson = jsonToJiraWorkitems();
    const dataPresentationHTML = renderDataAsRawJson(jirifiedJson, 'JSON Preview');

    showDataViewer(dataPresentationHTML);
    enableJsonPreviewToggle();
    showButton(downloadButtonId);
    showNextStepButton();
}

function handleDownloadJsonButtonClick(event) {
    const jsonString = JSON.stringify(jirifiedJson);

    const link = setupJsonDownloadLink(jsonString, downloadFileName());
    link.click();
}

function downloadFileName() {
    return loadedJsonFilename.split('.')[0] + '_jirified.json';
}




/*----------------------------------------
  DATA PROCESSING
  --------------------------------------*/

function workitemModelDefinition() {
    return getDefaultWorkitemModelDefinition();
}

function getDefaultWorkitemModelDefinition() {
    //value set by including defaultWorkitemModelDefinition.js in html where this js script is used
    return defaultWorkitemModelDefinition;
}

function scanWorkitemAttributes(workitemsJson) {
    let scannedAttributes = [];

    workitemsJson.forEach(function(workitem) {
        workitemAttributes = Object.keys(workitem);
        workitemAttributes.forEach(function(attribute) {
            if (!scannedAttributes.includes(attribute)) {
                scannedAttributes.push(attribute);
            }
        });
    });

    return scannedAttributes;
}

function jsonToJiraWorkitems() {
    let jiraWorkitems = [];

    loadedJson.forEach(function(jsonObject) {
        let jiraWorkitem = jsonToJiraWorkitem(jsonObject);
        jiraWorkitems.push(jiraWorkitem);
    });

    return jiraWorkitems;
}

function jsonToJiraWorkitem(jsonObject) {
    let jiraWorkitem = {};

    let modelDefinition = workitemModelDefinition();
    let attributes = modelDefinition.attributes;
    
    //only keep attributes in model definition
    attributes.forEach(function(attribute) {
        let jsonValue = jsonObject[attribute];
        if (Array.isArray(jsonValue) && isAttributeLimitedToSingleValue(attribute)) {
            jsonValue = jsonValue[0];
        }
        jiraWorkitem[attribute] = jsonValue;
    });

    return jiraWorkitem;
}

function isAttributeLimitedToSingleValue(attribute) {
    return workitemModelDefinition().singleValueLimitAttributes.includes(attribute);
}




/*----------------------------------------
  PRESENTATION LOGIC
  --------------------------------------*/

function showWorkItemChangesPreview(workitemModelDefinition, availableAttributes) {
    let attributeChanges = [];
    availableAttributes.forEach(function (attribute) {
        let keepingAttribute = workitemModelDefinition.attributes.includes(attribute);
        let limitedToSingleValue = isAttributeLimitedToSingleValue(attribute);
        attributeChange = renderAttributeChangeItem(attribute, keepingAttribute, limitedToSingleValue);
        attributeChanges.push(attributeChange);
    });

    let previewHTML = `
        <div>
            <hr>
            <span class='sub-title'>Workitem Changes Preview</span>
            <span class='attribute-heading'>attributes to keep:</span>

            <div class='attribute-preview'>
                <ul class='attributeChangesPreviewList'>
                    <li>${attributeChanges.join('</li><li>')}</li>
                </ul>
            </div>
        </div>
    `;

    showDataViewer(previewHTML);
}

function renderAttributeChangeItem(attribute, keepingAttribute, limitedToSingleValue) {
    let checked = keepingAttribute ? 'x' : '';
    let onlyUseFirstValueWarning = limitedToSingleValue ? '(LIMITED TO SINGLE VALUE)' : '';
    return `[${checked}] ${attribute} ${onlyUseFirstValueWarning}`;
}

function showDataViewer(htmlContent) {
    const elementId = 'dataViewer';
    document.getElementById(elementId).innerHTML = htmlContent;
}

function showFilename(filename) {
    console.log('display filename: ', filename);
    const contentHTML = 'JSON file: ' + filename;
    document.getElementById('fileName').textContent = contentHTML;
}